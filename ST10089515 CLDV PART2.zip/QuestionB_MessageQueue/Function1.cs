using System;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;

namespace QuestionB_MessageQueue
{
    public class Function1
    {
        [FunctionName("Function1")]
        public void Run([QueueTrigger("message-queue", Connection = "MyQueueCon")] string myQueueItem, ILogger log)
        {
            string Connstri = "Server=tcp:queuestorageserver1.database.windows.net,1433;Initial Catalog=dbQueues;Persist Security Info=False;User ID=kops;Password=Dbzgt1103;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";

            try
            {
                string[] attributes = myQueueItem.Split(':');
                string id = attributes[0];
                string center = attributes[1]; // Assuming center is the second attribute
                string vaccinationDate = attributes[2]; // Assuming vaccination date is the third attribute
                string serialNumber = attributes[3]; // Assuming serial number is the fourth attribute

                // PROCESS THE MESSAGE
                log.LogInformation($"Processing queue ID: {myQueueItem}");

                using (SqlConnection connection = new SqlConnection(Connstri))
                {
                    connection.Open();
                    using (SqlCommand command = connection.CreateCommand())
                    {
                        command.CommandText = "INSERT INTO MessagesC (Id, CENTER, VACCINATION_DATE, Serial_Number) VALUES (@Id, @Center, @VaccinationDate, @SerialNumber)";
                        command.Parameters.AddWithValue("@Id", id);
                        command.Parameters.AddWithValue("@Center", center);
                        command.Parameters.AddWithValue("@VaccinationDate", vaccinationDate);
                        command.Parameters.AddWithValue("@SerialNumber", serialNumber);
                        command.ExecuteNonQuery();
                    }
                }

                log.LogInformation($"Queue Message Added To the 'MessagesC' Table successfully, Id = {id}");
            }
            catch (Exception ex)
            {
                log.LogError($"Error processing queue message: {ex.Message}");
            }
        }
    }
}
